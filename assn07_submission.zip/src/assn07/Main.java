package assn07;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String,String> passwordManager = new PasswordManager<>();

        // your code below
        passwordManager.put("google", "hi");
        passwordManager.put("googl", "hi");
        System.out.println(passwordManager.size());
        passwordManager.put("microsoft", "h");
        System.out.println(passwordManager.checkDuplicates("hi"));
        System.out.println(passwordManager.keySet());
        System.out.println(passwordManager.get("google"));
        System.out.println(passwordManager.generatesafeRandomPassword(9));
        System.out.println(passwordManager.generatesafeRandomPassword(1));
        // infite loop to go back to "Enter master password"



        // loop to read and execute commands until "Exit" is entered




    }
}
